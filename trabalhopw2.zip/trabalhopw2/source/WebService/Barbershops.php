<?php
namespace Source\WebService;
use SorFabioSantos\Uploader\Uploader;
use Source\Models\User;
use Source\Core\JWTToken;

class barbershops extends Api{

}